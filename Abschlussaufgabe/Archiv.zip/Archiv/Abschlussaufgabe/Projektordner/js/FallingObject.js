var Abschlussaufgabe;
(function (Abschlussaufgabe) {
    class FallingObject {
        //        image: HTMLImageElement = new Image();
        constructor(_x, _y, _type) {
            this.score = 0;
            this.x = _x;
            this.y = _y;
            this.type = _type;
        }
        draw() { }
        ;
        move() { }
        ;
    }
    Abschlussaufgabe.FallingObject = FallingObject;
})(Abschlussaufgabe || (Abschlussaufgabe = {}));
//# sourceMappingURL=FallingObject.js.map